import numpy as np
# import cupy as np
import torch.utils.data as util_data
from torchvision import transforms
import torch
from PIL import Image
from tqdm import tqdm
import torchvision.datasets as dsets

def config_dataset(config):
    if "cifar" in config["dataset"]:
        config["topK"] = -1
        config["n_class"] = 10
    elif config["dataset"] in ["nuswide_21", "nuswide_21_m"]:
        config["topK"] = 5000
        config["n_class"] = 21
    elif config["dataset"] == "nuswide_81_m":
        config["topK"] = 5000
        config["n_class"] = 81
    elif config["dataset"] == "coco":
        config["topK"] = 5000
        config["n_class"] = 80
    elif config["dataset"] == "imagenet":
        config["topK"] = 1000
        config["n_class"] = 100
    elif config["dataset"] == "mirflickr":
        config["topK"] = -1
        config["n_class"] = 38
    elif config["dataset"] == "voc2012":
        config["topK"] = -1
        config["n_class"] = 20

    config["data_path"] = "/dataset/" + config["dataset"] + "/"
    if config["dataset"] == "nuswide_21":
        config["data_path"] = "/home/hzj/data3/nus-wide/"
        
    if config["dataset"] in ["nuswide_21_m", "nuswide_81_m"]:
        config["data_path"] = "/dataset/nus_wide_m/"
    if config["dataset"] == "coco":
        config["data_path"] = "/home/hzj/data3/COCO_2014/"
    if config["dataset"] == "voc2012":
        config["data_path"] = "/dataset/"
        
    if config["dataset"] == "imagenet":
        config["data_path"] = "/home/hzj/data3/Imagenet/"  
        
    if config["dataset"] == "mirflickr":
        config["data_path"] = "/home/ywj/data3/mirflickr/"    
        
    config["data"] = {
        "train_set": {"list_path": "./data/" + config["dataset"] + "/train.txt", "batch_size": config["batch_size"]},
        "database": {"list_path": "./data/" + config["dataset"] + "/database.txt", "batch_size": config["batch_size"]},
        "test": {"list_path": "./data/" + config["dataset"] + "/test.txt", "batch_size": config["batch_size"]}}
    return config


class ImageList(object):

    def __init__(self, data_path, image_list, transform):
        self.imgs = [(data_path + val.split()[0], np.array([int(la) for la in val.split()[1:]])) for val in image_list]  #分割字符串
        self.transform = transform

    def __getitem__(self, index):
        path, target = self.imgs[index]
        img = Image.open(path).convert('RGB')
        img = self.transform(img)
        return img, target, index   #返回每张图片的index， 图片，01000分类目标

    def __len__(self):
        return len(self.imgs)   #遍历完所有图片


def image_transform(resize_size, crop_size, data_set):
    if data_set == "train_set":
        step = [transforms.RandomHorizontalFlip(), transforms.RandomCrop(crop_size)]    #水平翻转，随机切割
    else:
        step = [transforms.CenterCrop(crop_size)]   #中心切割
    return transforms.Compose([transforms.Resize(resize_size)]
                              + step +
                              [transforms.ToTensor(),
                               transforms.Normalize(mean=[0.485, 0.456, 0.406],
                                                    std=[0.229, 0.224, 0.225])
                               ])


class MyCIFAR10(dsets.CIFAR10):
    def __getitem__(self, index):

        img, target = self.data[index], self.targets[index]
        img = Image.fromarray(img)
        img = self.transform(img)
        target = np.eye(10, dtype=np.int8)[np.array(target)]  #np.eye(10, dtype=np.int8)对角线全为1，其余为0的10*10的矩阵
        return img, target, index


def cifar_dataset(config):
    batch_size = config["batch_size"]

    train_size = 500
    test_size = 100

    if config["dataset"] == "cifar10-2":
        train_size = 5000
        test_size = 1000

    transform = transforms.Compose([
        transforms.Resize(config["crop_size"]),
        transforms.ToTensor(),
        transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
    ])

    # Dataset
    train_dataset = MyCIFAR10(root='/home/hzj/dataset/cifar/',
                              train=True,
                              transform=transform,
                              download=True)

    test_dataset = MyCIFAR10(root='/home/hzj/dataset/cifar/',
                             train=False,
                             transform=transform)

    database_dataset = MyCIFAR10(root='/home/hzj/dataset/cifar/',
                                 train=False,
                                 transform=transform)

    X = np.concatenate((train_dataset.data, test_dataset.data))  #拼接训练集和测试集
    L = np.concatenate((np.array(train_dataset.targets), np.array(test_dataset.targets)))  # 拼接标签和测试标签成一个numpy数组
    
    first = True
    for label in range(10):
        index = np.where(L == label)[0]   #label==targets
        N = index.shape[0]   # shape[0]是index的长度                     shape[0]图像的高度，shape[1]图像的宽度，shape[2]图像的通道数
        perm = np.random.permutation(N)   #随机排序N
        index = index[perm] #对index随机排序

        if first:
            test_index = index[:test_size]
            train_index = index[test_size: train_size + test_size]
            database_index = index[train_size + test_size:]
        else:
            test_index = np.concatenate((test_index, index[:test_size]))
            train_index = np.concatenate((train_index, index[test_size: train_size + test_size]))
            database_index = np.concatenate((database_index, index[train_size + test_size:]))
        first = False

    if config["dataset"] == "cifar10":
        # test:1000, train:5000, database:54000
        pass
    elif config["dataset"] == "cifar10-1":
        # test:1000, train:5000, database:59000
        database_index = np.concatenate((train_index, database_index))
    elif config["dataset"] == "cifar10-2":
        # test:10000, train:50000, database:50000
        database_index = train_index

    train_dataset.data = X[train_index]
    train_dataset.targets = L[train_index]
    test_dataset.data = X[test_index]
    test_dataset.targets = L[test_index]
    database_dataset.data = X[database_index]
    database_dataset.targets = L[database_index]

    print("train_dataset", train_dataset.data.shape[0])
    print("test_dataset", test_dataset.data.shape[0])
    print("database_dataset", database_dataset.data.shape[0])

    train_loader = torch.utils.data.DataLoader(dataset=train_dataset,
                                               batch_size=batch_size,
                                               shuffle=True,#true
                                               num_workers=4)

    test_loader = torch.utils.data.DataLoader(dataset=test_dataset,
                                              batch_size=batch_size,
                                              shuffle=True,#False
                                              num_workers=4)

    database_loader = torch.utils.data.DataLoader(dataset=database_dataset,
                                                  batch_size=batch_size,
                                                  shuffle=True,#False
                                                  num_workers=4)

    return train_loader, test_loader, database_loader, \
           train_index.shape[0], test_index.shape[0], database_index.shape[0]


def get_data(config):
    if "cifar" in config["dataset"]:
        return cifar_dataset(config)

    dsets = {}
    dset_loaders = {}
    data_config = config["data"]

    for data_set in ["train_set", "test", "database"]:
        dsets[data_set] = ImageList(config["data_path"],
                                    open(data_config[data_set]["list_path"]).readlines(),
                                    transform=image_transform(config["resize_size"], config["crop_size"], data_set))
        print(data_set, len(dsets[data_set]))
        dset_loaders[data_set] = util_data.DataLoader(dsets[data_set],
                                                      batch_size=data_config[data_set]["batch_size"],
                                                      shuffle=True, num_workers=4)

    return dset_loaders["train_set"], dset_loaders["test"], dset_loaders["database"], \
           len(dsets["train_set"]), len(dsets["test"]), len(dsets["database"])


def compute_result(dataloader, net, device):
    bs, clses = [], []  
    net.eval()
    for img, cls, _ in tqdm(dataloader):      
        clses.append(cls)
        out=(net(img.to(device)))
        bs.append(out.data.cpu())
    return torch.cat(bs).sign(), torch.cat(clses)

def CalcHammingDist(B1, B2):
    q = B2.shape[1]
    distH = 0.5 * (q - np.dot(B1, B2.transpose()))
    return distH

def CalcTopMap(rB, qB, retrievalL, queryL, topk):
    # print(retrievalL,retrievalL.shape) #  59000, 10  标签
    # print(queryL, queryL.shape)  #1000, 10
    # exit()
    #topk -1  
    num_query = queryL.shape[0]  #1000
    topkmap = 0
    for iter in tqdm(range(num_query)):
    
        gnd = (np.dot(queryL[iter, :], retrievalL.transpose()) > 0).astype(np.float32)
       
        hamm = CalcHammingDist(qB[iter, :], rB)
        ind = np.argsort(hamm)  # 对汉明距离排序
        gnd = gnd[ind]

        tgnd = gnd[0:topk]
        tsum = np.sum(tgnd).astype(int)
        if tsum == 0:
            continue
        count = np.linspace(1, tsum, tsum)

        tindex = np.asarray(np.where(tgnd == 1)) + 1.0
        topkmap_ = np.mean(count / (tindex))
        topkmap = topkmap + topkmap_
    topkmap = topkmap / num_query
    return topkmap

def pr_curve(tst_binary, trn_binary, tst_label, trn_label):
  
    trn_binary = np.asarray(trn_binary, np.int32)
    
    trn_label = trn_label.numpy()
 
    tst_binary = np.asarray(tst_binary, np.int32)
    tst_label = tst_label.numpy()
    query_times = tst_binary.shape[0]
    trainset_len = trn_binary.shape[0]
    
    AP = np.zeros(query_times)
    Ns = np.arange(1, trainset_len + 1)

    sum_p = np.zeros(trainset_len)
    sum_r = np.zeros(trainset_len)
    #f = open("./queryimg.txt","a+")
    for i in range(query_times):
  
        query_label = tst_label[i]
        
        query_binary = tst_binary[i,:]
        
        query_result = np.count_nonzero(query_binary != trn_binary, axis=1)    #don't need to divide binary length
        
        sort_indices = np.argsort(query_result)
        
       
        buffer_yes = ((query_label @ trn_label[sort_indices].transpose())>0).astype(float)
        print(buffer_yes)
        exit()
        
        P = np.cumsum(buffer_yes) / Ns       
        
        R = np.cumsum(buffer_yes)/np.sum(buffer_yes)#(trainset_len)*10
        sum_p = sum_p+P
        sum_r = sum_r+R
        #f.writelines(str(sort_indices[:10]))    检索可视化
        #f.write('\r\n')
    return sum_p/query_times,sum_r/query_times
 
def p_top(tst_binary, trn_binary, tst_label, trn_label):
  
    trn_binary = np.asarray(trn_binary, np.int32)
    trn_label = trn_label.numpy()
 
    tst_binary = np.asarray(tst_binary, np.int32)
    tst_label = tst_label.numpy()
    query_times = tst_binary.shape[0]
    trainset_len = trn_binary.shape[0]
    print(trainset_len)
    AP = np.zeros(query_times)
    Ns = np.arange(1, trainset_len + 1)

    sum_p = np.zeros(trainset_len)
    sum_r = np.zeros(trainset_len)
    
    for i in range(query_times):
  
        query_label = tst_label[i]
        query_binary = tst_binary[i,:]
        query_result = np.count_nonzero(query_binary != trn_binary, axis=1)    #don't need to divide binary length
        sort_indices = np.argsort(query_result)
        
       
        buffer_yes = ((query_label @ trn_label[sort_indices].transpose())>0).astype(float)
        
        P = np.cumsum(buffer_yes) / Ns       
        R = np.cumsum(buffer_yes)/np.sum(buffer_yes)#(trainset_len)*10
        sum_p = sum_p+P
        sum_r = sum_r+R
 
    return sum_p/query_times