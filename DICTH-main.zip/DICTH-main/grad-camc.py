import torch
import matplotlib.pyplot as plt
from torch.autograd import Function
#from torchvision import models
from torchvision import utils
import cv2
import sys
from collections import OrderedDict
import numpy as np
import argparse
import os
os.environ['KMP_DUPLICATE_LIB_OK'] = '0'
import torch.nn as nn
# import SKNet
# import senet.se_resnet
# import resnet
from network_ta1 import ResNet

plt.switch_backend('agg')

model = ResNet(64)
# model = SKNet.SKNet50()
#model.load_state_dict(torch.load(''))
# model1 = senet.se_resnet.se_resnet50()
model.load_state_dict(torch.load('/home/hzj/DeepHash-pytorch-master/save/DCLAH/coco-[64]-0.7071891565343227-model.pth'))
# model1 = resnet.__dict__['resnet50']()
# model1.load_state_dict(torch.load('/home/xlh/fe/modelss/resnet50_2/model.pth'))
# from models.resnet import resnet18
# i=0##testing in what
# resnet = resnet18(pretrained=True)#这里单独加载一个包含全连接层的resnet50模型
# image = []

def preprocess_image(img):
	means=[0.485, 0.456, 0.406]
	stds=[0.229, 0.224, 0.225]

	preprocessed_img = img.copy()[: , :, ::-1]
	for i in range(3):
		preprocessed_img[:, :, i] = preprocessed_img[:, :, i] - means[i]
		preprocessed_img[:, :, i] = preprocessed_img[:, :, i] / stds[i]
	preprocessed_img = \
		np.ascontiguousarray(np.transpose(preprocessed_img, (2, 0, 1)))
	preprocessed_img = torch.from_numpy(preprocessed_img)
	preprocessed_img.unsqueeze_(0)
	input = preprocessed_img
	input.requires_grad = True
	return input

def show_cam_on_image(img, mask,name):
	heatmap = cv2.applyColorMap(np.uint8(255*mask), cv2.COLORMAP_JET)
	heatmap = np.float32(heatmap) / 255
	cam = heatmap + np.float32(img)
	cam = cam / np.max(cam)
	# plt.gca().xaxis.set_major_locator(plt.NullLocator())
	# plt.gca().yaxis.set_major_locator(plt.NullLocator())
	# plt.subplots_adjust(top = 1, bottom = 0, right = 0, left = 0, hspace = 0, wspace = 0)
	#plt.margins(0,0) 
    
	plt.imshow(cam[..., -1::-1])#RGB-BRG转换
	plt.axis('off') # 关掉坐标轴为 off
	plt.show()
	#plt.title('image') # 图像题目
	cv2.imwrite("cam_1.jpg", np.uint8(255 * cam))
	cv2.imwrite("cam_1.png", np.uint8(255 * cam))

class FeatureExtractor():
    """ Class for extracting activations and 
    registering gradients from targetted intermediate layers """
    def __init__(self, model, target_layers):
        self.model = model
        self.target_layers = target_layers
        # print(self.target_layers)#['layer4']
        self.gradients = []

    def save_gradient(self, grad):
    	self.gradients.append(grad)
    	# print('grads_val',grad)#grads_val (1, 512, 6, 6)
    def __call__(self, x):
        outputs = []
        self.gradients = []
        x = self.model.feature_layers1(x)
        
        x = self.model.feature_layers2(x)
        #x = self.model.ta(x)
        # x = self.model.avgpool(x)
        for name, module in self.model._modules.items():##resnet50没有.feature这个特征，直接删除用就可以。
            # print(name)
            # print(module)
            # exit()
            # print(x.shape)  #1,3,192,192
            # exit()
            # x = x.squeeze()
            # print(x.shape)
            # exit()
            # x = x.astype(np.float32) / 255.
            # x = x[:, :, [2, 1, 0]]
            # x = torch.from_numpy(np.ascontiguousarray(np.transpose(x, (2, 0, 1)))).unsqueeze(dim=0).float()
            # print(x.shape,"+++++++++++++++++++++")
            # print(module, "*********************")
            # x = module(x)
            # print(x.shape,"---------------")
            # print('name=',name)
            # print('x.size()=',x.size())
            
            if name in self.target_layers:
                x.register_hook(self.save_gradient)
                outputs += [x]
        # print('outputs.size()=',x.size())
        # print('len(outputs)',len(outputs))
        # exit()
        x = self.model.avgpool(x)
        
        return outputs, x

class ModelOutputs():
	""" Class for making a forward pass, and getting:
	1. The network output.
	2. Activations from intermeddiate targetted layers.
	3. Gradients from intermeddiate targetted layers. """
	def __init__(self, model, target_layers,use_cuda):
		self.model = model
		self.feature_extractor = FeatureExtractor(self.model, target_layers)
		self.cuda = use_cuda
	def get_gradients(self):
		return self.feature_extractor.gradients

	def __call__(self, x):
		# print(x.shape)#torch.Size([1, 3, 192, 192])
		# exit()
		target_activations, output  = self.feature_extractor(x)
		# print(target_activations[0].shape)
		# print(output.shape)
		# exit()
		output = output.view(output.size(0), -1)#torch.Size([1, 512])
		# print(output.shape)
		# exit()
		#print('classfier=',output.size())
		# if self.cuda:
			# output = output.cuda()
			# output = resnet.fc(output).cuda()##这里就是为什么我们多加载一个resnet模型进来的原因，因为后面我们命名的model不包含fc层，但是这里又偏偏要使用。#
			# output = model.hash_layer(output).cuda()
		# else:
			# output = ResNet.hash_layer(output)
			# output = SKNet.SKNet50().fc(output)##这里对应use-cuda上更正一些bug,不然用use-cuda的时候会导致类型对不上,这样保证既可以在cpu上运行,gpu上运行也不会出问题.
		# print(output.shape)#torch.Size([1, 1000])
		# print(target_activations[0].shape)#torch.Size([1, 512, 6, 6])
		# exit()
		return target_activations, output

class GradCam():
	def __init__(self, model, target_layer_names, use_cuda):
		self.model = model
		self.model.eval()
		# exit()
		self.cuda = use_cuda
		if self.cuda:
			self.model = model.cuda()

		self.extractor = ModelOutputs(self.model, target_layer_names, use_cuda)

	def forward(self, input):
		# print(input)
		# exit()
		return self.model(input) 

	def __call__(self, input, index = None):
		if self.cuda:
			features, output = self.extractor(input.cuda())
		else:
			# print(input.shape)#torch.Size([1, 3, 192, 192])
			# exit()
			features, output = self.extractor(input)
		

		if index == None:
			index = np.argmax(output.cpu().data.numpy())
			# print(index)#660
			# exit()
		# print(output.size()[-1])#1000
		one_hot = np.zeros((1, output.size()[-1]), dtype = np.float32)
		# print(one_hot.shape)#(1, 1000)
		one_hot[0][index] = 1
		# print(one_hot)
		# exit()
		one_hot = torch.Tensor(torch.from_numpy(one_hot))
		one_hot.requires_grad = True
		if self.cuda:
			one_hot = torch.sum(one_hot.cuda() * output)
		else:
			# print(output)
			# print(one_hot)
			# print(one_hot * output)
			one_hot = torch.sum(one_hot * output)
			# print(one_hot)
			# exit()
		self.model.zero_grad()##features和classifier不包含，可以重新加回去试一试，会报错不包含这个对象。
		#self.model.zero_grad()
		one_hot.backward(retain_graph=True)

		grads_val = self.extractor.get_gradients()[-1].cpu().data.numpy()
		# print('---------------------------------------------------------------------------------')
		# print('grads_val',grads_val)#grads_val (1, 512, 6, 6)
		# exit()
		target = features[-1]
		# print(target.shape)#torch.Size([1, 512, 6, 6])
		# exit()
		target = target.cpu().data.numpy()[0, :]
		# print(target)#(512, 6, 6)
		# exit()
		weights = np.mean(grads_val, axis = (2, 3))[0, :]
		# print(weights.shape)(512,)
		# exit()
		# print(target.shape[1 : ])(6, 6)
		# exit()
		cam = np.zeros(target.shape[1 : ], dtype = np.float32)
		#print('cam',cam.shape)
		#print('features',features[-1].shape)
		#print('target',target.shape)
		for i, w in enumerate(weights):
			# print(w)
			# exit()
			cam += w * target[i, :, :]
		cam = np.maximum(cam, 0)
		cam = cv2.resize(cam, (192, 192))
		cam = cam - np.min(cam)
		cam = cam / np.max(cam)
		return cam

def get_args():
	parser = argparse.ArgumentParser()  #
	parser.add_argument('-use-cuda', action='store_true', default=True,
	                    help='Use NVIDIA GPU acceleration')
	parser.add_argument('-image', type=str, default='/home/hzj/DeepHash-pytorch-master/COCO_train2014_000000000081.jpg',  #图片放这个文件夹里
	                    help='Input image path')
	args = parser.parse_args()
	args.use_cuda = args.use_cuda and torch.cuda.is_available()
	if args.use_cuda:
	    print("Using GPU for acceleration")
	else:
	    print("Using CPU for computation")
	return args

if __name__ == '__main__':
	""" python grad_cam.py <path_to_image>
	1. Loads an image with opencv.
	2. Preprocesses it for VGG19 and converts to a pytorch variable.
	3. Makes a forward pass to find the category index with the highest score,
	and computes intermediate activations.
	Makes the visualization. """
	args = get_args()
	# Can work with any model, but it assumes that the model has a 
	# feature method, and a classifier method,
	# as in the VGG models in torchvision.
	# model = resnet18(pretrained=True)#这里相对vgg19而言我们处理的不一样，这里需要删除fc层，因为后面model用到的时候会用不到fc层，只查到fc层之前的所有层数。
	model = ResNet(32)
	# print(model)
	# exit()
	model.load_state_dict(torch.load('/home/hzj/DeepHash-pytorch-master/save/DCLAH/coco-[64]-0.7071891565343227-model.pth'))
	# model = senet.se_resnet.se_resnet50()
	# model.load_state_dict(torch.load('/home/xlh/fe/modelss/senet_2/model.pth'))
	# model = resnet.__dict__['resnet50']()
	# model.load_state_dict(torch.load('/home/xlh/fe/modelss/resnet50_2/model.pth'))
	# del model.conv2
	# del model.bn2
	# del model.relu2
	# del model.conv3
	# del model.bn3
	# del model.relu3
	# del model.fc
	# del model.softmax

	# del model.conv1
	# del model.bn1
	# del model.relu
	# del model.maxpool
	# del model.layer1
	# del model.layer2
	# del model.layer3
	# del model.layer4
	# del model.avgpool
	# del model.hash_layer
	# del model.simam_module
	# del model.feature_layers2
	# print(model)
	# exit()
	#modules = list(resnet.children())[:-1]
	#model = torch.nn.Sequential(*modules)
    
	# print(model)
	grad_cam = GradCam(model,target_layer_names = ["layer4"], use_cuda=args.use_cuda)  ##这里改成layer4（3,2,1）也很简单，我把每层name和size都打印出来了，想看哪层自己直接嵌套就可以了。（最后你会在终端看得到name的）
	# print(grad_cam)
	# exit()
	# x=os.walk(args.image)
	# for root,dirs,filename in x:
	# #print(type(grad_cam))
		# print(filename)
	img = cv2.imread(args.image)
	#img = cv2.imread(filename, 1)
	# for img in image:
	img = np.float32(cv2.resize(img, (192, 192))) / 255
	input = preprocess_image(img)
	input.required_grad = True
	# print('input.size()=',input.size())
	# If None, returns the map for the highest scoring category.
	# Otherwise, targets the requested index.
	target_index =None

	mask = grad_cam(input, target_index)
	i = 0
	i=i+1 
	show_cam_on_image(img, mask,i)