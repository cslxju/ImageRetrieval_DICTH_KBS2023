from utils.tools import *
from network_cota import *
from loguru import logger
import os
import torch
import torch.optim as optim
import time
import numpy as np

torch.multiprocessing.set_sharing_strategy('file_system')


# DBDH(Neurocomputing2020)
# paper [Deep balanced discrete hashing for image retrieval](https://www.sciencedirect.com/science/article/abs/pii/S0925231220306032)
# [DBDH] epoch:150, bit:48, dataset:cifar10-1, MAP:0.792, Best MAP: 0.793
# [DBDH] epoch:80, bit:48, dataset:nuswide_21, MAP:0.833, Best MAP: 0.834
def get_config():
    config = {
        "alpha": 0.1,#0.1
        "beta": 0.1,
        # "p": 1,
        "p": 2,
        # "optimizer": {"type": optim.SGD, "epoch_lr_decrease": 50,
        #               "optim_params": {"lr": 0.1, "weight_decay": 5e-4, "momentum": 0.9}},
        "optimizer": {"type": optim.RMSprop, "epoch_lr_decrease": 50,
                      "optim_params": {"lr": 1e-5, "weight_decay": 10 ** -5}},
        "info": "[DICTH]",
        "resize_size": 256,
        "crop_size": 224,
        "batch_size": 128,#64,128
        #"net": AlexNet,
        "net":ResNet,
        #"dataset": "cifar10",
        #"dataset": "cifar10-1",
        # "dataset": "cifar10-2",
        #"dataset": "coco",
        # "dataset": "mirflickr",
        # "dataset": "voc2012", 
        #"dataset": "imagenet",
        "dataset": "nuswide_21",
        # "dataset": "nuswide_21_m",
        # "dataset": "nuswide_81_m",
        "epoch": 1,#100,150
        "save_path": "save/DICTH",
        "test_map": 1,#5,10
        # "device":torch.device("cpu"),
        "device": torch.device("cuda:0"),
        "bit_list": [16],
    }
    config = config_dataset(config)
    return config


class DPSHLoss(torch.nn.Module):
    def __init__(self, config, bit):
        super(DPSHLoss, self).__init__()
        self.U = torch.zeros(config["num_train"], bit).float().to(config["device"])
        self.Y = torch.zeros(config["num_train"], config["n_class"]).float().to(config["device"])
        self.fc = torch.nn.Linear(bit, config["n_class"], bias=False).to(config["device"])
    def forward(self, u, y, ind, config):
        u = u.clamp(min=-1, max=1)#
        self.U[ind, :] = u.data
        self.Y[ind, :] = y.float()

        s = (y @ self.Y.t() > 0).float()
        inner_product = u @ self.U.t() * 0.5
        
        o = self.fc(u) 
        #1
        #pc = (1-o.softmax(dim=1).log() * y).sum(dim=1).mean()
        #2
        '''
        pc = (1 - o.softmax(dim=1)).sum(dim=1).mean()
        '''
        CE = (-o.softmax(dim=1).log() * y).sum(dim=1).mean()
        
        if "cifar10" in config["dataset"]:#2
            pc = (1-o.softmax(dim=1).log() * y).sum(dim=1).mean()
            #Lc = config["beta"] * (o - y * o + ((1 + (-o).exp()).log())).sum(dim=1).mean() 
        else:
            pc = (1 - o.softmax(dim=1)).sum(dim=1).mean()
        Lc = config["beta"] * (CE + pc) 

        likelihood_loss = (1 + (-(inner_product.abs())).exp()).log() + inner_product.clamp(min=0) - s * inner_product
        likelihood_loss = likelihood_loss.mean()

        if config["p"] == 1:
            quantization_loss = config["alpha"] * u.mean(dim=1).abs().mean()
        else:
            quantization_loss = config["alpha"] * u.mean(dim=1).pow(2).mean()

        return likelihood_loss + quantization_loss + Lc


def train_val(config, bit):
    device = config["device"]
    train_loader, test_loader, dataset_loader, num_train, num_test, num_dataset = get_data(config)
    config["num_train"] = num_train
    net = config["net"](bit).to(device)

    optimizer = config["optimizer"]["type"](net.parameters(), **(config["optimizer"]["optim_params"]))

    criterion = DPSHLoss(config, bit)

    Best_mAP = 0

    for epoch in range(config["epoch"]):

        lr = config["optimizer"]["optim_params"]["lr"] * (0.1 ** (epoch // config["optimizer"]["epoch_lr_decrease"]))
        for param_group in optimizer.param_groups:
            param_group['lr'] = lr

        current_time = time.strftime('%H:%M:%S', time.localtime(time.time()))

        print("%s[%2d/%2d][%s] bit:%d, dataset:%s, training...." % (
            config["info"], epoch + 1, config["epoch"], current_time, bit, config["dataset"]), end="")

        net.train()

        train_loss = 0
        for image, label, ind in train_loader:
            image = image.to(device)
            label = label.to(device)

            optimizer.zero_grad()
            u = net(image)

            loss = criterion(u, label.float(), ind, config)
            train_loss += loss.item()

            loss.backward()
            optimizer.step()

        train_loss = train_loss / len(train_loader)

        print("\b\b\b\b\b\b\b loss:%.3f" % (train_loss))

        if (epoch + 1) % config["test_map"] == 0:
            # print("calculating test binary code......")
            tst_binary, tst_label = compute_result(test_loader, net, device=device)
            
            # print("calculating dataset binary code.......")\
            trn_binary, trn_label = compute_result(dataset_loader, net, device=device)
            np.savetxt('DICTH_dataset_binary.txt',trn_binary,fmt='%d')
            np.savetxt('DICTH_dataset_label.txt',trn_label,fmt='%d')
            # print("calculating map.......")
            mAP = CalcTopMap(trn_binary.numpy(), tst_binary.numpy(), trn_label.numpy(), tst_label.numpy(),
                             config["topK"])
            P, R = pr_curve(
                    tst_binary,
                    trn_binary,
                    tst_label,
                    trn_label,
                )
            P_top = p_top(
                    tst_binary,
                    trn_binary,
                    tst_label,
                    trn_label,
                )         
            print(
                "%s epoch:%d, bit:%d, dataset:%s, MAP:%.3f" % (config["info"], epoch + 1, bit, config["dataset"], mAP))
            if mAP > Best_mAP:
                Best_mAP = mAP
                checkpoint = {                  
                    'P': P,
                    'R': R,
                    'P_top':P_top,
                }
                '''
            if "save_path" in config:
                 if not os.path.exists(config["save_path"]):
                     os.makedirs(config["save_path"])
                 print("save in ", config["save_path"])
                 np.save(os.path.join(config["save_path"], config["dataset"] + str(mAP) + "-" + "trn_binary.npy"),
                         trn_binary.numpy())
                 torch.save(net.state_dict(), os.path.join(config["save_path"], config["dataset"] + "-"+ str(config["bit_list"]) + "-" + str(mAP) + "-model.pth"))    
                '''
    print("bit:%d,Best MAP:%.3f" % (bit, Best_mAP))
    logger.info(str(bit)+'_map: {:.4f}'.format(mAP))
    
    if not os.path.isdir('result/'+config["dataset"]+'/'+config["info"]+'/'+str(bit)):
                os.makedirs('result//'+config["dataset"]+'//'+config["info"]+'//'+str(bit))
    P = checkpoint['P']
    R = checkpoint['R']
    P_top = checkpoint['P_top']
    np.savetxt ('result/'+config["dataset"]+'/'+config["info"]+'/'+str(bit)+'/'+'p.txt',P,fmt='%3.5f')  
    np.savetxt ('result/'+config["dataset"]+'/'+config["info"]+'/'+str(bit)+'/'+'r.txt',R,fmt='%3.5f')
    np.savetxt ('result/'+config["dataset"]+'/'+config["info"]+'/'+str(bit)+'/'+'P_top.txt',P_top,fmt='%3.5f')     


if __name__ == "__main__":
    config = get_config()
    print("base")
    logger.add('logs/DBDH/DBDH_{time}.log') 
    for bit in config["bit_list"]:
        train_val(config, bit)